.data

# ============================================================
# TEXTOS DE AYUDA
# ============================================================

salto: .asciiz "\n"

# ============================================================
# REGISTROS DEL MEDIDOR DE TENSI�N
# ============================================================

TensionControl: .word 0
TensionEstado:  .word 0
TensionSistol:  .word 110
TensionDiastol: .word 75


.text


# ============================================================
# MAIN
# ============================================================

main:

    # Llamar al controlador
    jal controlador_tension


    # --------------------------------------------------------
    # Al regresar:
    #
    # $v0 = tensi�n sist�lica
    # $v1 = tensi�n diast�lica
    # --------------------------------------------------------

    #Mostrar resultados
    move $a0, $v0
    li $v0, 1
    syscall
    
    la $a0, salto
    li $v0, 4
    syscall
    
    move $a0, $v1
    li $v0, 1
    syscall

    # Terminar
    li $v0, 10
    syscall



# ============================================================
# controlador_tension
#
# Inicia una medici�n escribiendo 1 en TensionControl.
#
# Despu�s espera hasta que:
#
#   TensionEstado = 1
#
# Finalmente:
#
#   $v0 = TensionSistol
#   $v1 = TensionDiastol
#
# ============================================================

controlador_tension:

    # --------------------------------------------------------
    # TensionControl = 1
    # --------------------------------------------------------

    la $t0, TensionControl
    li $t1, 1
    sw $t1, 0($t0)


esperar_tension:

    # Cambiar manualmente TensionEstado (solo por el bien de la simulacion)
    la $t0, TensionEstado
    li $v0, 5
    syscall
    sw $v0, 0($t0)

    # Leer TensionEstado
    la $t0, TensionEstado
    lw $t1, 0($t0)


    # �Estado = 1?
    li $t2, 1
    beq $t1, $t2, tension_lista


    # Si estado = 0:
    # todav�a est� midiendo.
    j esperar_tension



tension_lista:

    # --------------------------------------------------------
    # Leer tensi�n sist�lica
    # --------------------------------------------------------

    la $t0, TensionSistol
    lw $v0, 0($t0)


    # --------------------------------------------------------
    # Leer tensi�n diast�lica
    # --------------------------------------------------------

    la $t0, TensionDiastol
    lw $v1, 0($t0)


    # Regresar al programa que llam�
    jr $ra