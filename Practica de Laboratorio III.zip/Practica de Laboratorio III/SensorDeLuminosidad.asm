.data

# ============================================================
# TEXTOS DE AYUDA
# ============================================================

salto: .asciiz "\n"

# ============================================================
# REGISTROS DEL SENSOR DE LUMINOSIDAD
# ============================================================

LuzControl: .word 0
LuzEstado:  .word 0
LuzDatos:   .word 715


.text


# ============================================================
# MAIN
# ============================================================

main:

    # Inicializar sensor
    jal InicializarSensorLuz


    # Leer luminosidad
    jal LeerLuminosidad

    # --------------------------------------------------------
    # $v0 contiene:
    #   0  -> lectura correcta
    #  -1  -> error
    #
    # Si la lectura fue correcta:
    #   $v1 contiene la luminosidad
    # --------------------------------------------------------

    #Mostrar resultados
    move $a0, $v0
    li $v0, 1
    syscall
    
    la $a0, salto
    li $v0, 4
    syscall
    
    move $a0, $v1
    li $v0, 1
    syscall


    # Terminar programa
    li $v0, 10
    syscall


# ============================================================
# InicializarSensorLuz
#
# Inicializa el sensor escribiendo 1 en LuzControl.
# Despu�s espera hasta que:
#
#   LuzEstado = 1 -> sensor listo
#   LuzEstado = -1 -> error
#
# No devuelve ning�n valor.
# ============================================================

InicializarSensorLuz:

    # --------------------------------------------------------
    # LuzControl = 1
    # --------------------------------------------------------

    la $t0, LuzControl
    li $t1, 1
    sw $t1, 0($t0)


esperar_sensor:
    
    # Cambiar manualmente LuzEstado (solo por el bien de la simulacion)
    la $t0, LuzEstado
    li $v0, 5
    syscall
    sw $v0, 0($t0)
    

    # Leer LuzEstado
    la $t0, LuzEstado
    lw $t1, 0($t0)


    # �Est� listo?
    li $t2, 1
    beq $t1, $t2, sensor_listo


    # �Hubo error?
    li $t2, -1
    beq $t1, $t2, sensor_error


    # Si LuzEstado = 0,
    # todav�a no est� listo.
    j esperar_sensor


sensor_listo:

    jr $ra


sensor_error:

    # Tambi�n regresamos al llamador.
    # El procedimiento LeerLuminosidad
    # comprobar� nuevamente el estado.
    jr $ra



# ============================================================
# LeerLuminosidad
#
# Comprueba LuzEstado.
#
# Si:
#   LuzEstado = 1:
#       $v0 = 0
#       $v1 = valor de LuzDatos
#
#   LuzEstado = -1:
#       $v0 = -1
#       $v1 = 0
#
# ============================================================

LeerLuminosidad:

    # Leer estado
    la $t0, LuzEstado
    lw $t1, 0($t0)


    # Comprobar error
    li $t2, -1
    beq $t1, $t2, lectura_error


    # Comprobar que est� listo
    li $t2, 1
    beq $t1, $t2, lectura_correcta


    # Si todav�a no est� listo,
    # esperar.
    j LeerLuminosidad


lectura_correcta:

    # Leer LuzDatos
    la $t0, LuzDatos
    lw $v1, 0($t0)

    # C�digo de retorno = 0
    li $v0, 0

    jr $ra


lectura_error:

    # C�digo de retorno = -1
    li $v0, -1

    # No hay lectura v�lida
    li $v1, 0

    jr $ra
